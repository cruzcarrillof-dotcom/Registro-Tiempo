package com.example.registrotiempo

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

data class Registro(val descripcion:String, val inicio:Long, val fin:Long)

class MainActivity : AppCompatActivity() {
    private val registros = mutableListOf<Registro>()
    private var inicio: Long? = null
    private lateinit var desc: EditText
    private lateinit var estado: TextView
    private lateinit var total: TextView
    private lateinit var lista: LinearLayout
    private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        val titulo = TextView(this).apply { text="REGISTRO DE TIEMPO"; textSize=24f; setPadding(0,0,0,20) }
        desc = EditText(this).apply { hint="Descripción del paro o actividad" }
        estado = TextView(this).apply { text="Sin registro activo"; textSize=16f; setPadding(0,15,0,15) }
        val iniciar = Button(this).apply { text="▶ INICIAR" }
        val detener = Button(this).apply { text="⏹ DETENER"; isEnabled=false }
        total = TextView(this).apply { text="Total del día: 0 min"; textSize=18f; setPadding(0,20,0,10) }
        lista = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(titulo); root.addView(desc); root.addView(estado); root.addView(iniciar); root.addView(detener); root.addView(total)
        root.addView(lista)
        setContentView(root)

        iniciar.setOnClickListener {
            if (desc.text.toString().trim().isEmpty()) { desc.error="Escribe una descripción"; return@setOnClickListener }
            inicio=System.currentTimeMillis(); estado.text="Iniciado: ${fmt.format(Date(inicio!!))}"
            iniciar.isEnabled=false; detener.isEnabled=true
        }
        detener.setOnClickListener {
            val i=inicio ?: return@setOnClickListener
            val f=System.currentTimeMillis()
            registros.add(Registro(desc.text.toString().trim(), i, f))
            inicio=null; estado.text="Registro terminado: ${duracion(f-i)}"
            iniciar.isEnabled=true; detener.isEnabled=false; desc.setText("")
            refrescar()
        }
    }

    private fun duracion(ms:Long):String {
        val min=ms/60000; val h=min/60; val m=min%60
        return if(h>0) "$h h $m min" else "$m min"
    }

    private fun refrescar() {
        lista.removeAllViews()
        var suma=0L
        registros.forEachIndexed { idx,r ->
            suma += r.fin-r.inicio
            val t=TextView(this).apply {
                text="${idx+1}. ${r.descripcion}\n${fmt.format(Date(r.inicio))} → ${fmt.format(Date(r.fin))}\nDuración: ${duracion(r.fin-r.inicio)}"
                textSize=16f; setPadding(0,12,0,12)
            }
            lista.addView(t)
        }
        total.text="Total del día: ${duracion(suma)}"
    }
}
